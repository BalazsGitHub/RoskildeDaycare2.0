package com.example.myfirstapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstapplicationApplication.class, args);
	}

}
